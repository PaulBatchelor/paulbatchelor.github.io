lua pix.lua | convert -scale 400% - out.png
