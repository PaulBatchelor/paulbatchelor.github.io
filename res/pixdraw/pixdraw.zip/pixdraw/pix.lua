pal = {
"181 161 150",
"137 133 134",
"65 116 137",
"7 94 140",
"43 48 54",
"0 0 128",
"0 0 0",
"255 255 255"
}

img = {}
w = 64
h = 64

math.randomseed(os.time())

block1 = {
1, 1, 1, 1,
1, 0, 0, 1,
1, 0, 0, 1,
1, 1, 1, 1
}

block2 = {
0, 0, 0, 0,
0, 1, 1, 0,
0, 1, 1, 0,
0, 0, 0, 0
}

block = {block1, block2}


for y = 1, h do
    c = 1
    for x = 1, w do
        img[x + w * (y - 1)] = c
    end
end


function drawblock(img, blk, px, py, w, h) do
    for y = 1, h do
        for x = 1, w do
            c = blk[x + w * (y - 1)]
            offx = px + x
            offy = py + y
            if( c ~= 0 and px + x <= 64 and py + y <= 64) then
                img[offx + 64 * (offy - 1)] = c
            end
        end
    end
end
end

function colorize(block, color) 
    tbl = {}
    for k,v  in pairs(block) do
        if(v ~= 0) then
            tbl[k] = color
        else
            tbl[k] = 0
        end
    end
    return tbl
end

for i = 1, 256 do
    drawblock(img, colorize(block[math.random(2)], math.random(4) + 1), 
    (math.random(16) - 1) * 4, 
    (math.random(16) - 1) * 4, 4, 4)
end
io.write("P3\n")
io.write("\n")
io.write(string.format("%d %d\n", w, h))
io.write("255\n")

for k,v in pairs(img) do
    io.write(pal[v] .. " ")
end
