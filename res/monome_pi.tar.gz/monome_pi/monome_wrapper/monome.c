#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "lo/lo.h"

int done = 0;

void error(int num, const char *m, const char *path);

int lite_led_toggle(const char *path, const char *types, lo_arg **argv,
		    int argc, void *data, void *user_data);

void clear_all(){
    lo_address t = lo_address_new(NULL, "8080");
    int x, y;
    for(y = 0; y < 8; y++) {
	for(x = 0; x < 8; x++) {
	    lo_send(t, "/monome/led", "iii", x, y, 1);
	    usleep(50000);
	    lo_send(t, "/monome/led", "iii", x, y, 0);
	}
    }

}



int lite_me(const char *path, const char *types, lo_arg **argv,
		    int argc, void *data, void *user_data);

int main()
{
    int *grid[64];
    int i, j;
    clear_all();
    /* start a new server on port 7770 */
    lo_server_thread st = lo_server_thread_new("8000", error);
    lo_address t = lo_address_new(NULL, "8080");
    lo_address ext = lo_address_new("monomedest", "8080");

    lo_server_thread_add_method(st, "/monome/press", "iii", lite_led_toggle, t);
    //lo_server_thread_add_method(ext, "/monome/led", "iii", lite_me, t);
    lo_server_thread_start(st);


    while (!done) {
#ifdef WIN32
    Sleep(1);
#else
    usleep(1000);
#endif
    }

    return 0;
}

void error(int num, const char *msg, const char *path)
{
    printf("liblo server error %d in path %s: %s\n", num, path, msg);
    fflush(stdout);
}

int lite_led_toggle(const char *path, const char *types, lo_arg **argv,
		    int argc, void *data, void *user_data){
    lo_address t = lo_address_new("monomedest", "8000");
	int x, y, s;
	//lo_send((lo_address *)user_data, "/monome/led", "iii", argv[0]->i, argv[1]->i, argv[2]->i);
	lo_send(t, "/monome/press", "iii", argv[0]->i, argv[1]->i, argv[2]->i);
	fflush(stdout);
	return 0;
}
int lite_me(const char *path, const char *types, lo_arg **argv,
		    int argc, void *data, void *user_data){
    lo_address t = lo_address_new("monomedest", "8000");
	int x, y, s;
	//lo_send((lo_address *)user_data, "/monome/led", "iii", argv[0]->i, argv[1]->i, argv[2]->i);
	lo_send(t, "/monome/led", "iii", argv[0]->i, argv[1]->i, argv[2]->i);
	fflush(stdout);
	return 0;
}
